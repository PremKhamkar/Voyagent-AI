import AuthLayout from "../../layouts/AuthLayout";

function Login() {
  return <AuthLayout />;
}

export default Login;