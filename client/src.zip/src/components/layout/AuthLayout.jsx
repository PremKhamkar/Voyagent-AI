function AuthLayout() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8">
        <h1 className="text-3xl font-bold text-red-600">
          Auth Layout Working
        </h1>
      </div>
    </main>
  );
}

export default AuthLayout;