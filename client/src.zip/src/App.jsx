function App() {
  return (
    <div
      style={{
        height: "100vh",
        background: "green",
        color: "white",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "40px",
      }}
    >
      APP WORKING
    </div>
  );
}

export default App;